# Veyra branding pack for Next.js 15 / 16 (App Router)

## Quick setup
1. Copy `app/favicon.ico`, `app/icon.png`, `app/apple-icon.png`, `app/manifest.ts` into your existing `app/` folder.
2. Copy the contents of `public/` into your project `public/`.
3. Merge metadata from `layout.metadata.example.tsx` into your existing `app/layout.tsx`. Keep your current providers, fonts, and `<html>` / `<body>` layout.
4. Reference the main wordmark in a header with `<Image src="/veyra-logo.png" alt="Veyra" width={600} height={235} className="h-auto w-40" />` (adjust dimensions/styles for your layout).
5. For a square mark use `/veyra-mark.png` or `/veyra-app-icon.png`.

## Files
- `app/favicon.ico`: classic browser favicon
- `app/icon.png`: Next file-based icon, 512px transparent
- `app/apple-icon.png`: iOS Apple home-screen icon, 180px dark background
- `app/manifest.ts`: installable app metadata
- `public/veyra-logo.png`: complete logo plus tagline, transparent and cropped
- `public/veyra-mark.png`: icon only, transparent artwork crop
- `public/veyra-app-icon.png`: centered transparent square mark
- `public/icon-192.png`, `icon-512.png`: PWA icons
- `public/favicon-16x16.png`, `favicon-32x32.png`: standard size assets
- `public/og-image.png`: Open Graph / social sharing card 1200x630

Note: the logo wordmark uses dark lettering; display it against a LIGHT header background. The icon works on either theme. The original image is raster art; vector SVG is not included.
