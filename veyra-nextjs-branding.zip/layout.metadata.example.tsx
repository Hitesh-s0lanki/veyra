// Merge these exports with your existing app/layout.tsx.
// Do not replace your existing layout just to add metadata.
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: { default: "Veyra – AI Video Generator", template: "%s | Veyra" },
  description: "Imagine it. See it move. Turn text and images into cinematic AI videos with Veyra.",
  applicationName: "Veyra",
  icons: {
    icon: [{ url: "/favicon.ico", sizes: "any" }, { url: "/icon.png", type: "image/png" }],
    apple: [{ url: "/apple-icon.png", sizes: "180x180" }],
  },
  openGraph: {
    type: "website",
    title: "Veyra – Imagine it. See it move.",
    description: "Turn text and images into cinematic AI videos.",
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Veyra AI Video Generator" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Veyra – AI Video Generator",
    images: ["/og-image.png"],
  },
};

export const viewport: Viewport = { themeColor: "#090F29" };
