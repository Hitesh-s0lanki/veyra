# Video Generation MCP client setup

This bundle runs a local stdio MCP client for the Video Generation API. The API is hosted separately. Python 3.12 or 3.13 is recommended.

1. Extract this ZIP and open a terminal in the extracted folder.
2. Create a virtual environment: `python -m venv .venv`.
3. Install the client packages: `.venv/Scripts/python -m pip install -r requirements-mcp.txt` on Windows, or `.venv/bin/python -m pip install -r requirements-mcp.txt` on macOS/Linux.
4. In your MCP client's configuration, set the command to the absolute path of that virtual environment's Python, and set args to the absolute path of `mcp_server.py`.
5. Set `VIDEO_API_BASE_URL` to the current hosted API HTTPS URL, and `VIDEO_API_TOKEN` to a bearer token issued for your account. Keep the token private. The website's browser session is not an MCP token.
6. Install the entire `skills/video-generation-mcp` folder in your agent client's skills directory. Use `AGENT_PROMPT.md` as the agent's initial instruction if your client supports it.

The MCP server exposes seven tools. `generate_video` starts a billable job. `download_video` writes on the machine running this MCP process. Local image upload is restricted to `VIDEO_MCP_IMAGE_ROOT` (the extracted bundle directory by default); output defaults to its `outputs` directory.
